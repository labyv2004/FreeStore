//
//  FreeStoreApp.swift
//  FreeStore
//
//  Created by kovalchukradimir on 21.02.26.
//

import SwiftUI

@main
struct FreeStoreApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
