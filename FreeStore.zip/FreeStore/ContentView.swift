import SwiftUI
import AppKit
import Combine

// MARK: - Модель приложения (AppInfo)
struct AppInfo: Identifiable, Codable {
    /// Стабильный идентификатор, чтобы статус установки не сбрасывался между сессиями
    let id: String
    let name: String
    let description: String
    let version: String
    let author: String
    let iconPath: String
    let downloadPath: String
    let os: String

    enum CodingKeys: String, CodingKey {
        case id
        case name, description, version, author, iconPath, downloadPath, os
    }

    init(id: String? = nil,
         name: String,
         description: String,
         version: String,
         author: String,
         iconPath: String,
         downloadPath: String,
         os: String) {
        // Если id в JSON нет — используем downloadPath как стабильный ключ
        self.id = id ?? downloadPath
        self.name = name
        self.description = description
        self.version = version
        self.author = author
        self.iconPath = iconPath
        self.downloadPath = downloadPath
        self.os = os
    }
}

// MARK: - GitHub Content
struct GitHubContent: Codable {
    let name: String
    let type: String
    let download_url: String?
}

// MARK: - Download Delegate
class DownloadDelegate: NSObject, URLSessionDownloadDelegate {
    var onProgress: ((Double) -> Void)?
    var onCompletion: ((URL?, Error?) -> Void)?

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        let progress: Double
        if totalBytesExpectedToWrite > 0 {
            progress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
        } else {
            progress = 0
        }
        DispatchQueue.main.async { self.onProgress?(progress) }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        DispatchQueue.main.async { self.onCompletion?(location, nil) }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error = error { DispatchQueue.main.async { self.onCompletion?(nil, error) } }
    }
}

// MARK: - Менеджер установленных приложений
class InstalledAppsManager: ObservableObject {
    static let shared = InstalledAppsManager()
    private let defaults = UserDefaults.standard
    private let installedKey = "installedApps_v2"

    /// Ключ словаря = AppInfo.id (стабильный id), значение = путь до файла
    @Published var installedApps: [String: URL] = [:]

    private init() {
        load()
        validateInstalledApps()
    }

    func load() {
        guard let data = defaults.data(forKey: installedKey),
              let dict = try? JSONDecoder().decode([String: String].self, from: data) else { return }

        installedApps = dict.reduce(into: [:]) { result, pair in
            if let url = URL(string: pair.value) {
                result[pair.key] = url
            }
        }
    }

    func save() {
        let dict = installedApps.reduce(into: [String: String]()) { $0[$1.key] = $1.value.absoluteString }
        guard let data = try? JSONEncoder().encode(dict) else { return }
        defaults.set(data, forKey: installedKey)
    }

    func markAsInstalled(app: AppInfo, at url: URL) {
        installedApps[app.id] = url
        save()
        validateInstalledApps()
    }

    func uninstall(app: AppInfo) -> Bool {
        guard let url = installedApps[app.id] else { return false }
        try? FileManager.default.removeItem(at: url)
        installedApps.removeValue(forKey: app.id)
        save()
        return true
    }

    func isInstalled(app: AppInfo) -> Bool {
        installedApps[app.id] != nil
    }

    func pathForApp(app: AppInfo) -> URL? {
        installedApps[app.id]
    }

    func validateInstalledApps() {
        var changed = false
        for (id, url) in installedApps {
            if !FileManager.default.fileExists(atPath: url.path) {
                installedApps.removeValue(forKey: id)
                changed = true
            }
        }
        if changed { save() }
    }
}

// MARK: - Менеджер избранных приложений
class FavoritesManager: ObservableObject {
    static let shared = FavoritesManager()
    private let defaults = UserDefaults.standard
    private let favoritesKey = "favoriteApps_v1"

    @Published var favoriteIDs: Set<String> = []

    private init() {
        load()
    }

    private func load() {
        if let stored = defaults.array(forKey: favoritesKey) as? [String] {
            favoriteIDs = Set(stored)
        }
    }

    private func save() {
        defaults.set(Array(favoriteIDs), forKey: favoritesKey)
    }

    func isFavorite(app: AppInfo) -> Bool {
        favoriteIDs.contains(app.id)
    }

    func toggleFavorite(app: AppInfo) {
        if favoriteIDs.contains(app.id) {
            favoriteIDs.remove(app.id)
        } else {
            favoriteIDs.insert(app.id)
        }
        save()
    }
}

// MARK: - ViewModel
class StoreViewModel: ObservableObject {
    @Published var apps: [AppInfo] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var searchText = ""

    private let repoOwner = "labyv2004"
    private let repoName = "FreeStore"
    private let branch = "main"

    var filteredApps: [AppInfo] {
        apps.filter { app in
            app.os == "macos" && (searchText.isEmpty ||
                app.name.localizedCaseInsensitiveContains(searchText) ||
                app.description.localizedCaseInsensitiveContains(searchText))
        }
    }

    private var appsFolderPath: String {
        "https://api.github.com/repos/\(repoOwner)/\(repoName)/contents/apps?ref=\(branch)"
    }

    private var cacheURL: URL {
        FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("FreeStore/apps.json")
    }

    func loadApps() async {
        await MainActor.run { isLoading = true }
        defer { Task { await MainActor.run { isLoading = false } } }

        if let cachedApps = loadCachedApps() {
            await MainActor.run { apps = cachedApps }
            return
        }

        await fetchAppsFromGitHub()
    }

    private func loadCachedApps() -> [AppInfo]? {
        guard FileManager.default.fileExists(atPath: cacheURL.path) else { return nil }
        do {
            let data = try Data(contentsOf: cacheURL)
            return try JSONDecoder().decode([AppInfo].self, from: data)
        } catch {
            print("⚠️ Ошибка чтения кэша: \(error)")
            return nil
        }
    }

    private func saveCachedApps(_ apps: [AppInfo]) {
        do {
            let data = try JSONEncoder().encode(apps)
            try FileManager.default.createDirectory(at: cacheURL.deletingLastPathComponent(),
                                                    withIntermediateDirectories: true)
            try data.write(to: cacheURL)
        } catch {
            print("⚠️ Ошибка сохранения кэша: \(error)")
        }
    }

    private func fetchAppsFromGitHub() async {
        guard let url = URL(string: appsFolderPath) else {
            await MainActor.run { errorMessage = "Неверный URL репозитория" }
            return
        }

        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            guard let httpResponse = response as? HTTPURLResponse else {
                await MainActor.run { errorMessage = "Некорректный ответ сервера" }
                return
            }

            if httpResponse.statusCode == 404 {
                await MainActor.run {
                    apps = []
                    errorMessage = nil
                }
                return
            }

            guard httpResponse.statusCode == 200 else {
                await MainActor.run { errorMessage = "Ошибка сервера: код \(httpResponse.statusCode)" }
                return
            }

            let contents = try JSONDecoder().decode([GitHubContent].self, from: data)
            var newApps: [AppInfo] = []
            for item in contents where item.type == "dir" {
                if let appInfo = await parseAppFolder(item.name) {
                    newApps.append(appInfo)
                }
            }

            let sortedApps = newApps.sorted { $0.name < $1.name }
            await MainActor.run {
                apps = sortedApps
                saveCachedApps(sortedApps)
            }
        } catch {
            await MainActor.run { errorMessage = "Ошибка загрузки: \(error.localizedDescription)" }
        }
    }

    private func parseAppFolder(_ folderName: String) async -> AppInfo? {
        let baseURL = "https://raw.githubusercontent.com/\(repoOwner)/\(repoName)/\(branch)/apps/\(folderName)/"

        if let info = await fetchJSON(from: baseURL + "info.json") as? [String: String] {
            let id = info["id"]
            let name = info["name"] ?? folderName
            let description = info["description"] ?? "Нет описания"
            let version = info["version"] ?? "1.0"
            let author = info["author"] ?? "Неизвестно"
            let os = info["os"] ?? "macos"
            let iconPath = baseURL + "icon.png"
            let downloadPath = baseURL + "\(folderName).zip"

            return AppInfo(
                id: id,
                name: name,
                description: description,
                version: version,
                author: author,
                iconPath: iconPath,
                downloadPath: downloadPath,
                os: os
            )
        } else {
            let name = folderName
            let description = "Приложение \(folderName)"
            let version = "1.0"
            let author = "Неизвестный автор"
            let os = "macos"
            let iconPath = baseURL + "icon.png"
            let downloadPath = baseURL + "\(folderName).zip"

            return AppInfo(
                id: downloadPath,
                name: name,
                description: description,
                version: version,
                author: author,
                iconPath: iconPath,
                downloadPath: downloadPath,
                os: os
            )
        }
    }

    private func fetchJSON(from urlString: String) async -> Any? {
        guard let url = URL(string: urlString) else { return nil }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            return try JSONSerialization.jsonObject(with: data)
        } catch {
            return nil
        }
    }
}

// MARK: - Скелетон для строки списка
struct SkeletonAppRow: View {
    var body: some View {
        HStack(spacing: 12) {
            RoundedRectangle(cornerRadius: 6, style: .continuous)
                .fill(Color.gray.opacity(0.25))
                .frame(width: 32, height: 32)

            VStack(alignment: .leading, spacing: 6) {
                RoundedRectangle(cornerRadius: 4, style: .continuous)
                    .fill(Color.gray.opacity(0.25))
                    .frame(width: 140, height: 10)

                RoundedRectangle(cornerRadius: 4, style: .continuous)
                    .fill(Color.gray.opacity(0.18))
                    .frame(width: 220, height: 8)
            }

            Spacer()
        }
        .redacted(reason: .placeholder)
        .padding(.vertical, 8)
        .padding(.horizontal, 4)
    }
}

// MARK: - Анимированный эффект сияния (shimmer)
struct ShimmerModifier: ViewModifier {
    @State private var phase: CGFloat = -0.6

    func body(content: Content) -> some View {
        content
            .overlay(
                GeometryReader { proxy in
                    let width = proxy.size.width
                    let gradient = LinearGradient(
                        gradient: Gradient(colors: [
                            Color.white.opacity(0),
                            Color.white.opacity(0.55),
                            Color.white.opacity(0)
                        ]),
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                    Rectangle()
                        .fill(gradient)
                        .frame(width: width * 0.8)
                        .rotationEffect(.degrees(8))
                        .offset(x: phase * width * 2)
                }
                .clipped()
                .allowsHitTesting(false)
            )
            .onAppear {
                withAnimation(
                    .linear(duration: 1.2)
                        .repeatForever(autoreverses: false)
                ) {
                    phase = 0.8
                }
            }
    }
}

extension View {
    func shimmering() -> some View {
        modifier(ShimmerModifier())
    }
}

// MARK: - Стиль кнопок с анимацией нажатия
struct PressablePlainButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
            .opacity(configuration.isPressed ? 0.9 : 1.0)
            .animation(.spring(response: 0.25, dampingFraction: 0.85), value: configuration.isPressed)
    }
}

struct PrimaryActionButtonStyle: ButtonStyle {
    let tint: Color

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(tint)
                    .shadow(color: tint.opacity(configuration.isPressed ? 0.2 : 0.35),
                            radius: configuration.isPressed ? 4 : 10,
                            x: 0, y: configuration.isPressed ? 2 : 6)
            )
            .foregroundColor(.white)
            .scaleEffect(configuration.isPressed ? 0.96 : 1.0)
            .animation(.spring(response: 0.25, dampingFraction: 0.8), value: configuration.isPressed)
    }
}

struct SecondaryActionButtonStyle: ButtonStyle {
    let tint: Color

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .strokeBorder(tint.opacity(0.7), lineWidth: 1)
                    .background(
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(Color(NSColor.windowBackgroundColor))
                    )
                    .shadow(color: tint.opacity(configuration.isPressed ? 0.0 : 0.12),
                            radius: configuration.isPressed ? 0 : 6,
                            x: 0, y: configuration.isPressed ? 0 : 4)
            )
            .foregroundColor(tint)
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
            .animation(.spring(response: 0.25, dampingFraction: 0.85), value: configuration.isPressed)
    }
}

// MARK: - Apple Intelligence style progress view
struct AppleIntelligenceProgressView: View {
    var progress: Double
    @State private var shimmerPhase: CGFloat = -0.6
    
    private var clampedProgress: Double {
        min(max(progress, 0), 1)
    }
    
    var body: some View {
        GeometryReader { proxy in
            let width = proxy.size.width
            let height = proxy.size.height
            let filledWidth = max(width * clampedProgress, height)
            
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: height / 2, style: .continuous)
                    .fill(Color.gray.opacity(0.18))
                
                RoundedRectangle(cornerRadius: height / 2, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [
                                Color.accentColor.opacity(0.2),
                                Color.accentColor,
                                Color.accentColor.opacity(0.85)
                            ],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(width: filledWidth)
                    .overlay(
                        RoundedRectangle(cornerRadius: height / 2, style: .continuous)
                            .stroke(Color.white.opacity(0.4), lineWidth: 0.5)
                    )
                
                RoundedRectangle(cornerRadius: height / 2, style: .continuous)
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color.white.opacity(0),
                                Color.white.opacity(0.8),
                                Color.white.opacity(0)
                            ]),
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(width: min(width * 0.35, filledWidth))
                    .offset(x: shimmerPhase * width)
                    .blendMode(.screen)
            }
            .onAppear {
                withAnimation(
                    .linear(duration: 1.4)
                    .repeatForever(autoreverses: false)
                ) {
                    shimmerPhase = 1.2
                }
            }
        }
    }
}

// MARK: - Фильтр по статусу установки
enum AppStatusFilter: String, CaseIterable, Identifiable {
        case all = "Все"
        case installed = "Установленные"
        case notInstalled = "Не установленные"
        
    var id: Self { self }
}

// MARK: - Сортировка приложений
enum AppSortOption: String, CaseIterable, Identifiable {
    case name = "По имени"
    case installedFirst = "Сначала установленные"
    case author = "По автору"
    
    var id: Self { self }
}

// MARK: - Разделы приложения
enum AppSection: String, CaseIterable, Identifiable {
    case catalog = "Каталог"
    case favorites = "Избранное"
    
    var id: Self { self }
}

// MARK: - Основное представление
struct ContentView: View {
        @StateObject private var viewModel = StoreViewModel()
        @State private var showingAddInfo = false
        @State private var selectedFilteredIndex: Int? = nil
        @State private var statusFilter: AppStatusFilter = .all
        @State private var sortOption: AppSortOption = .name
        @State private var searchFlash = false
        @State private var section: AppSection = .catalog
        @State private var showOnboarding = false
        @AppStorage("freestore_hasSeenOnboarding") private var hasSeenOnboarding = false
        @ObservedObject private var favorites = FavoritesManager.shared
        @Namespace private var appNamespace
        
        private var displayedApps: [AppInfo] {
            let filteredByStatus: [AppInfo] = {
                switch statusFilter {
                case .all:
                    return viewModel.filteredApps
                case .installed:
                    return viewModel.filteredApps.filter { InstalledAppsManager.shared.isInstalled(app: $0) }
                case .notInstalled:
                    return viewModel.filteredApps.filter { !InstalledAppsManager.shared.isInstalled(app: $0) }
                }
            }()
            
            let base: [AppInfo] = {
                switch section {
                case .catalog:
                    return filteredByStatus
                case .favorites:
                    return filteredByStatus.filter { FavoritesManager.shared.isFavorite(app: $0) }
                }
            }()
            
            switch sortOption {
            case .name:
                return base.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
            case .installedFirst:
                return base.sorted { lhs, rhs in
                    let lInstalled = InstalledAppsManager.shared.isInstalled(app: lhs)
                    let rInstalled = InstalledAppsManager.shared.isInstalled(app: rhs)
                    if lInstalled == rInstalled {
                        return lhs.name < rhs.name
                    }
                    return lInstalled && !rInstalled
                }
            case .author:
                return base.sorted {
                    $0.author.localizedCaseInsensitiveCompare($1.author) == .orderedAscending
                }
            }
        }
        
        var body: some View {
            NavigationView {
                List {
                    if viewModel.isLoading && viewModel.apps.isEmpty {
                        ForEach(0..<6, id: \.self) { _ in
                            SkeletonAppRow()
                        }
                        .transition(.opacity)
                    } else {
                        ForEach(Array(displayedApps.enumerated()), id: \.element.id) { index, app in
                            Button(action: {
                                withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
                                    selectedFilteredIndex = index
                                }
                            }) {
                                HStack(spacing: 12) {
                                    AsyncImage(url: URL(string: app.iconPath)) { phase in
                                        if let image = phase.image {
                                            image.resizable()
                                                .frame(width: 32, height: 32)
                                                .cornerRadius(6)
                                                .shadow(color: selectedFilteredIndex == index ? Color.accentColor.opacity(0.35) : Color.clear,
                                                        radius: 8, x: 0, y: 4)
                                                .matchedGeometryEffect(id: "icon-\(app.id)", in: appNamespace)
                                        } else if phase.error != nil {
                                            Image(systemName: "app.dashed")
                                                .resizable()
                                                .frame(width: 32, height: 32)
                                                .foregroundColor(.gray)
                                        } else {
                                            ProgressView()
                                                .frame(width: 32, height: 32)
                                        }
                                    }
                                    
                                    VStack(alignment: .leading, spacing: 2) {
                                        HStack {
                                            Text(app.name)
                                                .font(.headline)
                                                .foregroundColor(selectedFilteredIndex == index ? .accentColor : .primary)
                                                .matchedGeometryEffect(id: "title-\(app.id)", in: appNamespace)
                                            
                                            Button {
                                                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                                    favorites.toggleFavorite(app: app)
                                                }
                                            } label: {
                                                Image(systemName: favorites.isFavorite(app: app) ? "star.fill" : "star")
                                                    .foregroundColor(favorites.isFavorite(app: app) ? .yellow : .secondary)
                                                    .imageScale(.small)
                                            }
                                            .buttonStyle(PressablePlainButtonStyle())
                                            
                                            if InstalledAppsManager.shared.isInstalled(app: app) {
                                                Text("Установлено")
                                                    .font(.caption2)
                                                    .padding(.horizontal, 6)
                                                    .padding(.vertical, 2)
                                                    .background(Color.accentColor.opacity(0.15))
                                                    .foregroundColor(.accentColor)
                                                    .cornerRadius(4)
                                            }
                                        }
                                        
                                        if !app.description.isEmpty {
                                            Text(app.description)
                                                .font(.subheadline)
                                                .foregroundColor(.secondary)
                                                .lineLimit(1)
                                        }
                                    }
                                    
                                    Spacer()
                                }
                                .padding(.vertical, 8)
                                .padding(.horizontal, 4)
                            }
                            .buttonStyle(PressablePlainButtonStyle())
                            .background(
                                ZStack {
                                    if selectedFilteredIndex == index {
                                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                                            .fill(Color.accentColor.opacity(0.08))
                                            .shadow(color: Color.accentColor.opacity(0.15), radius: 10, x: 0, y: 6)
                                            .transition(.opacity.combined(with: .scale))
                                    }
                                }
                            )
                            .cornerRadius(8)
                            .animation(.spring(response: 0.35, dampingFraction: 0.85), value: viewModel.searchText)
                            .animation(.spring(response: 0.35, dampingFraction: 0.85), value: statusFilter)
                        }
                    }
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
                .background(Color(.windowBackgroundColor))
                .navigationTitle("FreeStore")
                .toolbar {
                    ToolbarItem(placement: .automatic) {
                        Picker("", selection: $section) {
                            ForEach(AppSection.allCases) { section in
                                Text(section.rawValue).tag(section)
                            }
                        }
                        .pickerStyle(.segmented)
                        .frame(width: 220)
                        .help("Разделы магазина")
                    }
                    
                    ToolbarItem(placement: .automatic) {
                        Picker("", selection: $statusFilter) {
                            ForEach(AppStatusFilter.allCases) { scope in
                                Text(scope.rawValue).tag(scope)
                            }
                        }
                        .pickerStyle(.segmented)
                        .frame(width: 260)
                        .help("Фильтр по статусу установки")
                    }
                    
                    ToolbarItem(placement: .automatic) {
                        Button(action: refresh) {
                            Image(systemName: "arrow.clockwise")
                                .rotationEffect(.degrees(viewModel.isLoading ? 360 : 0))
                                .animation(
                                    viewModel.isLoading
                                    ? .linear(duration: 1.0).repeatForever(autoreverses: false)
                                    : .default,
                                    value: viewModel.isLoading
                                )
                        }
                        .disabled(viewModel.isLoading)
                        .keyboardShortcut("r", modifiers: .command)
                        .help("Обновить список (\u{2318}R)")
                    }
                    
                    ToolbarItem(placement: .automatic) {
                        Button(action: showAddInfo) {
                            Image(systemName: "plus")
                        }
                        .keyboardShortcut("n", modifiers: .command)
                        .help("Как добавить приложение (\u{2318}N)")
                    }
                    
                    ToolbarItem(placement: .status) {
                        HStack(spacing: 8) {
                            Picker("", selection: $sortOption) {
                                ForEach(AppSortOption.allCases) { option in
                                    Text(option.rawValue).tag(option)
                                }
                            }
                            .frame(width: 190)
                            .help("Сортировка списка приложений")
                            
                            Text("\(displayedApps.count) приложений")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                }
                .toolbarBackground(.visible, for: .windowToolbar)
                .overlay {
                    if viewModel.isLoading {
                        ZStack {
                            Color.black.opacity(0.12)
                                .ignoresSafeArea()
                            VStack(spacing: 12) {
                                ProgressView()
                                    .scaleEffect(1.2)
                                Text("Загружаем список приложений…")
                                    .font(.callout)
                                    .foregroundColor(.secondary)
                            }
                            .padding(24)
                            .background(.thinMaterial)
                            .cornerRadius(16)
                            .shadow(radius: 20)
                            .transition(.scale.combined(with: .opacity))
                        }
                    } else if let error = viewModel.errorMessage {
                        Text(error)
                            .foregroundColor(.red)
                            .padding()
                            .transition(.opacity.combined(with: .move(edge: .top)))
                    } else if viewModel.filteredApps.isEmpty {
                        VStack(spacing: 8) {
                            Image(systemName: "magnifyingglass")
                                .font(.system(size: 32))
                                .foregroundColor(.secondary.opacity(0.6))
                            Text("Нет приложений")
                                .foregroundColor(.secondary)
                        }
                        .transition(.opacity)
                    }
                }
                
                // Детальный экран
                if let selectedIndex = selectedFilteredIndex, selectedIndex < displayedApps.count {
                    AppDetailView(
                        apps: displayedApps,
                        currentIndex: Binding(
                            get: { selectedIndex },
                            set: { selectedFilteredIndex = $0 }
                        ),
                        installedManager: InstalledAppsManager.shared,
                        namespace: appNamespace
                    )
                    .transition(.asymmetric(insertion: .move(edge: .trailing).combined(with: .opacity),
                                            removal: .move(edge: .leading).combined(with: .opacity)))
                    .id(selectedIndex)
                } else {
                    Text("Выберите приложение")
                        .font(.title2)
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
            }
            .frame(minWidth: 800, minHeight: 500)
            .searchable(text: $viewModel.searchText,
                        placement: .toolbar,
                        prompt: "Поиск")
            .task { await viewModel.loadApps() }
            .onAppear {
                if !hasSeenOnboarding {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                        showOnboarding = true
                    }
                }
            }
            .onChange(of: viewModel.searchText) { _ in
                selectedFilteredIndex = nil
                withAnimation(.easeInOut(duration: 0.25)) {
                    searchFlash = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                    withAnimation(.easeOut(duration: 0.25)) {
                        searchFlash = false
                    }
                }
            }
            .onChange(of: statusFilter) { _ in
                selectedFilteredIndex = nil
            }
            .alert("Как добавить своё приложение", isPresented: $showingAddInfo) {
                Button("OK") { }
            } message: {
                Text("""
            Чтобы добавить приложение в FreeStore, напишите боту в Telegram: @freestoremac_bot
            Отправьте команду /start и следуйте инструкциям.
            После проверки ваше приложение появится в репозитории.
            """)
            }
            .overlay(alignment: .top) {
                if searchFlash && !viewModel.searchText.isEmpty {
                    HStack {
                        Image(systemName: "line.3.horizontal.decrease.circle")
                        Text("Поиск обновлён")
                    }
                    .font(.caption)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(.thinMaterial)
                    .cornerRadius(20)
                    .shadow(radius: 8)
                    .padding(.top, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
                }
            }
            .sheet(isPresented: $showOnboarding, onDismiss: {
                hasSeenOnboarding = true
            }) {
                OnboardingView {
                    hasSeenOnboarding = true
                    showOnboarding = false
                }
            }
        }
        
        func refresh() { Task { await viewModel.loadApps() } }
        func showAddInfo() { showingAddInfo = true }
    }
    
    // MARK: - Детальный экран с пролистыванием
    struct AppDetailView: View {
        let apps: [AppInfo]
        @Binding var currentIndex: Int
        @ObservedObject var installedManager: InstalledAppsManager
        var namespace: Namespace.ID
        
        var body: some View {
            GeometryReader { geometry in
                ScrollViewReader { proxy in
                    ScrollView(.horizontal, showsIndicators: false) {
                        LazyHStack(spacing: 0) {
                            ForEach(apps.indices, id: \.self) { index in
                                AppDetailPage(app: apps[index],
                                              installedManager: installedManager,
                                              namespace: namespace)
                                .frame(width: geometry.size.width)
                                .id(index)
                            }
                        }
                    }
                    .onAppear {
                        DispatchQueue.main.async {
                            proxy.scrollTo(currentIndex, anchor: .center)
                        }
                    }
                    .onChange(of: currentIndex) { newValue in
                        withAnimation {
                            proxy.scrollTo(newValue, anchor: .center)
                        }
                    }
                }
            }
            .toolbar {
                ToolbarItemGroup(placement: .automatic) {
                    Button(action: previousPage) {
                        Image(systemName: "chevron.left")
                    }
                    .disabled(currentIndex <= 0)
                    
                    Button(action: nextPage) {
                        Image(systemName: "chevron.right")
                    }
                    .disabled(currentIndex >= apps.count - 1)
                }
            }
            .onAppear {
                installedManager.validateInstalledApps()
            }
        }
        
        private func previousPage() {
            withAnimation { currentIndex = max(currentIndex - 1, 0) }
        }
        private func nextPage() {
            withAnimation { currentIndex = min(currentIndex + 1, apps.count - 1) }
        }
    }
    
    // MARK: - Страница детального просмотра одного приложения
    struct AppDetailPage: View {
        let app: AppInfo
        @ObservedObject var installedManager: InstalledAppsManager
        @State private var isDownloading = false
        @State private var downloadProgress: Double = 0
        @State private var downloadTask: URLSessionDownloadTask?
        @State private var downloadDelegate: DownloadDelegate?
        @State private var showUninstallAlert = false
        @State private var isLaunching = false
        @ObservedObject private var favorites = FavoritesManager.shared
        var namespace: Namespace.ID
        
        var body: some View {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    HStack {
                        Spacer()
                        VStack(spacing: 16) {
                            AsyncImage(url: URL(string: app.iconPath)) { phase in
                                if let image = phase.image {
                                    image.resizable()
                                        .frame(width: 128, height: 128)
                                        .cornerRadius(16)
                                        .shadow(radius: 5)
                                        .scaleEffect(isDownloading ? 0.9 : 1.0)
                                        .animation(.spring(), value: isDownloading)
                                        .matchedGeometryEffect(id: "icon-\(app.id)", in: namespace)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 20, style: .continuous)
                                                .stroke(Color.accentColor.opacity(isLaunching ? 0.8 : 0),
                                                        lineWidth: 3)
                                                .shadow(color: Color.accentColor.opacity(isLaunching ? 0.7 : 0),
                                                        radius: 12, x: 0, y: 0)
                                                .padding(-6)
                                                .animation(.easeInOut(duration: 0.35), value: isLaunching)
                                        )
                                } else if phase.error != nil {
                                    Image(systemName: "app.dashed")
                                        .resizable()
                                        .frame(width: 128, height: 128)
                                        .foregroundColor(.gray)
                                } else {
                                    ProgressView().frame(width: 128, height: 128)
                                }
                            }
                            Text(app.name)
                                .font(.largeTitle)
                                .bold()
                                .multilineTextAlignment(.center)
                                .matchedGeometryEffect(id: "title-\(app.id)", in: namespace)
                        }
                        Spacer()
                    }
                    .padding(.top)
                    
                    if !app.description.isEmpty {
                        Text(app.description)
                            .font(.body)
                            .padding(.horizontal)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    
                    VStack(alignment: .leading, spacing: 12) {
                        LabeledContent("Версия", value: app.version)
                        Divider()
                        LabeledContent("Автор", value: app.author)
                    }
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
                    .padding(.horizontal)
                    
                    HStack {
                        Spacer()
                        Button {
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                favorites.toggleFavorite(app: app)
                            }
                        } label: {
                            Label(favorites.isFavorite(app: app) ? "В избранном" : "В избранное",
                                  systemImage: favorites.isFavorite(app: app) ? "star.fill" : "star")
                            .padding(.horizontal, 14)
                            .padding(.vertical, 6)
                            .background(
                                Capsule(style: .continuous)
                                    .fill(Color.yellow.opacity(favorites.isFavorite(app: app) ? 0.25 : 0.08))
                            )
                        }
                        .buttonStyle(PressablePlainButtonStyle())
                        .padding(.bottom, 4)
                        Spacer()
                    }
                    
                    HStack {
                        Spacer()
                        if isDownloading {
                            VStack {
                                AppleIntelligenceProgressView(progress: downloadProgress)
                                    .frame(width: 260, height: 10)
                                Text("Загрузка…")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        } else {
                            if installedManager.isInstalled(app: app) {
                                HStack(spacing: 20) {
                                    Button(action: launchApp) {
                                        Label("Запустить", systemImage: "play")
                                            .frame(maxWidth: .infinity)
                                    }
                                    .buttonStyle(PrimaryActionButtonStyle(tint: .green))
                                    .tint(.green)
                                    
                                    Button(action: { showUninstallAlert = true }) {
                                        Label("Удалить", systemImage: "trash")
                                            .frame(maxWidth: .infinity)
                                    }
                                    .buttonStyle(SecondaryActionButtonStyle(tint: .red))
                                    .tint(.red)
                                }
                                .frame(maxWidth: 400)
                            } else {
                                Button(action: startDownload) {
                                    Label("Скачать", systemImage: "arrow.down.circle")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(PrimaryActionButtonStyle(tint: .accentColor))
                                .controlSize(.large)
                                .padding(.horizontal, 40)
                                .transition(.scale.combined(with: .opacity))
                            }
                        }
                        Spacer()
                    }
                    .padding(.vertical)
                    
                    Spacer()
                }
                .padding(.vertical, 24)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(.windowBackgroundColor))
            .alert("Удалить приложение?", isPresented: $showUninstallAlert) {
                Button("Отмена", role: .cancel) { }
                Button("Удалить", role: .destructive) {
                    if installedManager.uninstall(app: app) {
                        installedManager.validateInstalledApps()
                    }
                }
            } message: {
                Text("Приложение будет удалено с вашего компьютера.")
            }
            .onReceive(installedManager.objectWillChange) { _ in }
        }
        
        private func startDownload() {
            guard let url = URL(string: app.downloadPath) else { return }
            isDownloading = true
            downloadProgress = 0
            let delegate = DownloadDelegate()
            delegate.onProgress = { progress in
                withAnimation(.linear(duration: 0.12)) {
                    downloadProgress = min(max(progress, 0), 1)
                }
            }
            delegate.onCompletion = { location, error in
                isDownloading = false
                downloadTask = nil
                downloadDelegate = nil
                if let error = error {
                    print("❌ Ошибка загрузки: \(error)")
                    return
                }
                guard let location = location else { return }
                let savePanel = NSSavePanel()
                savePanel.title = "Сохранить приложение"
                savePanel.nameFieldStringValue = url.lastPathComponent
                savePanel.directoryURL = URL(fileURLWithPath: "/Applications")
                savePanel.begin { result in
                    if result == .OK, let dest = savePanel.url {
                        do {
                            try FileManager.default.moveItem(at: location, to: dest)
                            installedManager.markAsInstalled(app: app, at: dest)
                        } catch {
                            print("❌ Ошибка сохранения: \(error)")
                        }
                    }
                }
            }
            downloadDelegate = delegate
            let session = URLSession(configuration: .default, delegate: delegate, delegateQueue: OperationQueue())
            downloadTask = session.downloadTask(with: url)
            downloadTask?.resume()
        }
        
        private func launchApp() {
            guard let path = installedManager.pathForApp(app: app) else { return }
            withAnimation(.easeInOut(duration: 0.25)) {
                isLaunching = true
            }
            NSWorkspace.shared.open(path)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                withAnimation(.easeOut(duration: 0.25)) {
                    isLaunching = false
                }
            }
        }
    }


