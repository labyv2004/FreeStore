import SwiftUI
import AppKit
import Combine

//==============================================================================
// MARK: - Модель приложения (AppInfo)
//==============================================================================
struct AppInfo: Identifiable, Codable {
    let id = UUID()
    let name: String
    let description: String
    let version: String
    let author: String
    let iconPath: String
    let downloadPath: String

    enum CodingKeys: String, CodingKey {
        case name, description, version, author, iconPath, downloadPath
    }
}

//==============================================================================
// MARK: - GitHub Content (вспомогательная структура)
//==============================================================================
struct GitHubContent: Codable {
    let name: String
    let type: String
    let download_url: String?
}

//==============================================================================
// MARK: - Download Delegate для отслеживания прогресса
//==============================================================================
class DownloadDelegate: NSObject, URLSessionDownloadDelegate {
    var onProgress: ((Double) -> Void)?
    var onCompletion: ((URL?, Error?) -> Void)?

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        let progress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
        DispatchQueue.main.async {
            self.onProgress?(progress)
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        DispatchQueue.main.async {
            self.onCompletion?(location, nil)
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error = error {
            DispatchQueue.main.async {
                self.onCompletion?(nil, error)
            }
        }
    }
}

//==============================================================================
// MARK: - Менеджер установленных приложений
//==============================================================================
class InstalledAppsManager: ObservableObject {
    static let shared = InstalledAppsManager()
    private let defaults = UserDefaults.standard
    private let installedKey = "installedApps"

    @Published var installedApps: [UUID: URL] = [:]

    private init() {
        load()
        validateInstalledApps()
    }

    func load() {
        guard let data = defaults.data(forKey: installedKey),
              let dict = try? JSONDecoder().decode([String: String].self, from: data) else { return }
        installedApps = dict.compactMapValues { URL(string: $0) }.reduce(into: [:]) { result, pair in
            if let uuid = UUID(uuidString: pair.key) {
                result[uuid] = pair.value
            }
        }
    }

    func save() {
        let dict = installedApps.reduce(into: [String: String]()) { $0[$1.key.uuidString] = $1.value.absoluteString }
        guard let data = try? JSONEncoder().encode(dict) else { return }
        defaults.set(data, forKey: installedKey)
    }

    func markAsInstalled(appId: UUID, at url: URL) {
        installedApps[appId] = url
        save()
        // После сохранения сразу проверяем целостность (на случай коллизий)
        validateInstalledApps()
    }

    func uninstall(appId: UUID) -> Bool {
        guard let url = installedApps[appId] else { return false }
        try? FileManager.default.removeItem(at: url)
        installedApps.removeValue(forKey: appId)
        save()
        return true
    }

    func isInstalled(appId: UUID) -> Bool {
        installedApps[appId] != nil
    }

    func pathForApp(appId: UUID) -> URL? {
        installedApps[appId]
    }

    // Проверяет, существуют ли файлы установленных приложений, и удаляет записи о пропавших
    func validateInstalledApps() {
        var changed = false
        for (id, url) in installedApps {
            if !FileManager.default.fileExists(atPath: url.path) {
                installedApps.removeValue(forKey: id)
                changed = true
            }
        }
        if changed {
            save()
        }
    }
}

//==============================================================================
// MARK: - ViewModel
//==============================================================================
class StoreViewModel: ObservableObject {
    @Published var apps: [AppInfo] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    private let repoOwner = "labyv2004"
    private let repoName = "FreeStore"
    private let branch = "main"

    private var appsFolderPath: String {
        "https://api.github.com/repos/\(repoOwner)/\(repoName)/contents/apps?ref=\(branch)"
    }

    private var cacheURL: URL {
        FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("FreeStore/apps.json")
    }

    func loadApps() async {
        await MainActor.run { isLoading = true }
        defer { Task { await MainActor.run { isLoading = false } } }

        if let cachedApps = loadCachedApps() {
            await MainActor.run { apps = cachedApps }
            return
        }

        await fetchAppsFromGitHub()
    }

    private func loadCachedApps() -> [AppInfo]? {
        guard FileManager.default.fileExists(atPath: cacheURL.path) else { return nil }
        do {
            let data = try Data(contentsOf: cacheURL)
            return try JSONDecoder().decode([AppInfo].self, from: data)
        } catch {
            print("⚠️ Ошибка чтения кэша: \(error)")
            return nil
        }
    }

    private func saveCachedApps(_ apps: [AppInfo]) {
        do {
            let data = try JSONEncoder().encode(apps)
            try FileManager.default.createDirectory(at: cacheURL.deletingLastPathComponent(),
                                                    withIntermediateDirectories: true)
            try data.write(to: cacheURL)
        } catch {
            print("⚠️ Ошибка сохранения кэша: \(error)")
        }
    }

    private func fetchAppsFromGitHub() async {
        guard let url = URL(string: appsFolderPath) else {
            await MainActor.run { errorMessage = "Неверный URL репозитория" }
            return
        }

        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            guard let httpResponse = response as? HTTPURLResponse else {
                await MainActor.run { errorMessage = "Некорректный ответ сервера" }
                return
            }

            if httpResponse.statusCode == 404 {
                await MainActor.run {
                    apps = []
                    errorMessage = nil
                }
                return
            }

            guard httpResponse.statusCode == 200 else {
                await MainActor.run { errorMessage = "Ошибка сервера: код \(httpResponse.statusCode)" }
                return
            }

            let contents = try JSONDecoder().decode([GitHubContent].self, from: data)
            var newApps: [AppInfo] = []
            for item in contents where item.type == "dir" {
                if let appInfo = await parseAppFolder(item.name) {
                    newApps.append(appInfo)
                }
            }

            let sortedApps = newApps.sorted { $0.name < $1.name }
            await MainActor.run {
                apps = sortedApps
                saveCachedApps(sortedApps)
            }
        } catch {
            await MainActor.run { errorMessage = "Ошибка загрузки: \(error.localizedDescription)" }
        }
    }

    private func parseAppFolder(_ folderName: String) async -> AppInfo? {
        let baseURL = "https://raw.githubusercontent.com/\(repoOwner)/\(repoName)/\(branch)/apps/\(folderName)/"

        if let info = await fetchJSON(from: baseURL + "info.json") as? [String: String] {
            let name = info["name"] ?? folderName
            let description = info["description"] ?? "Нет описания"
            let version = info["version"] ?? "1.0"
            let author = info["author"] ?? "Неизвестно"
            let iconPath = baseURL + "icon.png"
            let downloadPath = baseURL + "\(folderName).zip"

            return AppInfo(
                name: name,
                description: description,
                version: version,
                author: author,
                iconPath: iconPath,
                downloadPath: downloadPath
            )
        } else {
            let name = folderName
            let description = "Приложение \(folderName)"
            let version = "1.0"
            let author = "Неизвестный автор"
            let iconPath = baseURL + "icon.png"
            let downloadPath = baseURL + "\(folderName).zip"

            return AppInfo(
                name: name,
                description: description,
                version: version,
                author: author,
                iconPath: iconPath,
                downloadPath: downloadPath
            )
        }
    }

    private func fetchJSON(from urlString: String) async -> Any? {
        guard let url = URL(string: urlString) else { return nil }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            return try JSONSerialization.jsonObject(with: data)
        } catch {
            return nil
        }
    }
}

//==============================================================================
// MARK: - Основное представление (список приложений)
//==============================================================================
struct ContentView: View {
    @StateObject private var viewModel = StoreViewModel()
    @State private var showingAddInfo = false
    @State private var selectedAppIndex: Int? = nil

    var body: some View {
        NavigationView {
            // Левая панель: только иконка и название
            List(Array(viewModel.apps.enumerated()), id: \.element.id) { index, app in
                Button(action: {
                    withAnimation(.easeInOut) {
                        selectedAppIndex = index
                    }
                }) {
                    HStack(spacing: 12) {
                        AsyncImage(url: URL(string: app.iconPath)) { phase in
                            if let image = phase.image {
                                image.resizable()
                                    .frame(width: 32, height: 32)
                                    .cornerRadius(6)
                            } else if phase.error != nil {
                                Image(systemName: "app.dashed")
                                    .resizable()
                                    .frame(width: 32, height: 32)
                                    .foregroundColor(.gray)
                            } else {
                                ProgressView()
                                    .frame(width: 32, height: 32)
                            }
                        }

                        Text(app.name)
                            .font(.headline)
                            .foregroundColor(selectedAppIndex == index ? .accentColor : .primary)

                        Spacer()
                    }
                    .padding(.vertical, 6)
                }
                .buttonStyle(.plain)
                .background(selectedAppIndex == index ? Color.accentColor.opacity(0.1) : Color.clear)
                .cornerRadius(8)
            }
            .listStyle(.plain)
            .navigationTitle("FreeStore")
            .toolbar {
                ToolbarItem(placement: .automatic) {
                    Button(action: refresh) {
                        Image(systemName: "arrow.clockwise")
                    }
                    .disabled(viewModel.isLoading)
                }
                ToolbarItem(placement: .automatic) {
                    Button(action: showAddInfo) {
                        Image(systemName: "plus")
                    }
                }
            }
            .overlay {
                if viewModel.isLoading {
                    ProgressView("Загрузка...")
                } else if let error = viewModel.errorMessage {
                    Text(error)
                        .foregroundColor(.red)
                        .padding()
                } else if viewModel.apps.isEmpty {
                    Text("Нет доступных приложений")
                        .foregroundColor(.secondary)
                }
            }

            // Детальный экран с возможностью листания
            if let selectedIndex = selectedAppIndex, selectedIndex < viewModel.apps.count {
                AppDetailView(
                    apps: viewModel.apps,
                    currentIndex: Binding(
                        get: { selectedIndex },
                        set: { selectedAppIndex = $0 }
                    ),
                    installedManager: InstalledAppsManager.shared
                )
                .transition(.asymmetric(insertion: .opacity, removal: .identity))
                .id(selectedIndex) // принудительно пересоздаём при смене индекса
            } else {
                Text("Выберите приложение")
                    .font(.title2)
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .frame(minWidth: 800, minHeight: 500)
        .task {
            await viewModel.loadApps()
        }
        .alert("Как добавить своё приложение", isPresented: $showingAddInfo) {
            Button("OK") { }
        } message: {
            Text("""
            Чтобы добавить приложение в FreeStore, напишите боту в Telegram: @freestoremac_bot
            Отправьте команду /start и следуйте инструкциям.
            После проверки ваше приложение появится в репозитории.
            """)
        }
    }

    func refresh() {
        Task { await viewModel.loadApps() }
    }

    func showAddInfo() {
        showingAddInfo = true
    }
}

//==============================================================================
// MARK: - Детальный экран с пролистыванием (ScrollView вместо TabView)
//==============================================================================
struct AppDetailView: View {
    let apps: [AppInfo]
    @Binding var currentIndex: Int
    @ObservedObject var installedManager: InstalledAppsManager

    var body: some View {
        GeometryReader { geometry in
            ScrollViewReader { proxy in
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(spacing: 0) {
                        ForEach(apps.indices, id: \.self) { index in
                            AppDetailPage(app: apps[index], installedManager: installedManager)
                                .frame(width: geometry.size.width)
                                .id(index)
                        }
                    }
                }
                .onAppear {
                    DispatchQueue.main.async {
                        proxy.scrollTo(currentIndex, anchor: .center)
                    }
                }
                .onChange(of: currentIndex) { newValue in
                    withAnimation {
                        proxy.scrollTo(newValue, anchor: .center)
                    }
                }
            }
        }
        .toolbar {
            ToolbarItemGroup(placement: .automatic) {
                Button(action: previousPage) {
                    Image(systemName: "chevron.left")
                }
                .disabled(currentIndex <= 0)

                Button(action: nextPage) {
                    Image(systemName: "chevron.right")
                }
                .disabled(currentIndex >= apps.count - 1)
            }
        }
        .onAppear {
            // При появлении проверяем целостность установленных приложений
            installedManager.validateInstalledApps()
        }
    }

    private func previousPage() {
        withAnimation {
            currentIndex = max(currentIndex - 1, 0)
        }
    }

    private func nextPage() {
        withAnimation {
            currentIndex = min(currentIndex + 1, apps.count - 1)
        }
    }
}

//==============================================================================
// MARK: - Страница детального просмотра одного приложения
//==============================================================================
struct AppDetailPage: View {
    let app: AppInfo
    @ObservedObject var installedManager: InstalledAppsManager
    @State private var isDownloading = false
    @State private var downloadProgress: Double = 0
    @State private var downloadTask: URLSessionDownloadTask?
    @State private var showUninstallAlert = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                // Центрируем иконку и название
                HStack {
                    Spacer()
                    VStack(spacing: 16) {
                        AsyncImage(url: URL(string: app.iconPath)) { phase in
                            if let image = phase.image {
                                image.resizable()
                                    .frame(width: 128, height: 128)
                                    .cornerRadius(16)
                                    .shadow(radius: 5)
                                    .scaleEffect(isDownloading ? 0.9 : 1.0)
                                    .animation(.spring(), value: isDownloading)
                            } else if phase.error != nil {
                                Image(systemName: "app.dashed")
                                    .resizable()
                                    .frame(width: 128, height: 128)
                                    .foregroundColor(.gray)
                            } else {
                                ProgressView()
                                    .frame(width: 128, height: 128)
                            }
                        }

                        Text(app.name)
                            .font(.largeTitle)
                            .bold()
                            .multilineTextAlignment(.center)
                    }
                    Spacer()
                }
                .padding(.top)

                // Описание
                if !app.description.isEmpty {
                    Text(app.description)
                        .font(.body)
                        .padding(.horizontal)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }

                // Информационная карточка
                VStack(alignment: .leading, spacing: 12) {
                    LabeledContent("Версия", value: app.version)
                    Divider()
                    LabeledContent("Автор", value: app.author)
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)
                .padding(.horizontal)

                // Кнопки в зависимости от статуса установки
                HStack {
                    Spacer()
                    if isDownloading {
                        VStack {
                            ProgressView(value: downloadProgress, total: 1.0)
                                .frame(width: 250)
                            Text("Загрузка...")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    } else {
                        if installedManager.isInstalled(appId: app.id) {
                            HStack(spacing: 20) {
                                Button(action: launchApp) {
                                    Label("Запустить", systemImage: "play")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(.green)

                                Button(action: { showUninstallAlert = true }) {
                                    Label("Удалить", systemImage: "trash")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.bordered)
                                .tint(.red)
                            }
                            .frame(maxWidth: 400)
                        } else {
                            Button(action: startDownload) {
                                Label("Скачать", systemImage: "arrow.down.circle")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.borderedProminent)
                            .controlSize(.large)
                            .padding(.horizontal, 40)
                            .transition(.scale.combined(with: .opacity))
                        }
                    }
                    Spacer()
                }
                .padding(.vertical)

                Spacer()
            }
            .padding(.vertical, 24)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.windowBackgroundColor))
        .alert("Удалить приложение?", isPresented: $showUninstallAlert) {
            Button("Отмена", role: .cancel) { }
            Button("Удалить", role: .destructive) {
                if installedManager.uninstall(appId: app.id) {
                    // После удаления проверяем целостность (на всякий случай)
                    installedManager.validateInstalledApps()
                }
            }
        } message: {
            Text("Приложение будет удалено с вашего компьютера.")
        }
        .onReceive(installedManager.objectWillChange) { _ in
            // Принудительно обновляем view при изменении installedManager
        }
    }

    // MARK: - Скачивание
    private func startDownload() {
        guard let url = URL(string: app.downloadPath) else { return }
        isDownloading = true
        downloadProgress = 0

        let delegate = DownloadDelegate()
        delegate.onProgress = { progress in
            withAnimation {
                downloadProgress = progress
            }
        }
        delegate.onCompletion = { location, error in
            isDownloading = false
            if let error = error {
                print("❌ Ошибка загрузки: \(error)")
                return
            }
            guard let location = location else { return }

            let savePanel = NSSavePanel()
            savePanel.title = "Сохранить приложение"
            savePanel.nameFieldStringValue = url.lastPathComponent
            savePanel.directoryURL = URL(fileURLWithPath: "/Applications")
            savePanel.begin { result in
                if result == .OK, let destinationURL = savePanel.url {
                    do {
                        try FileManager.default.moveItem(at: location, to: destinationURL)
                        installedManager.markAsInstalled(appId: app.id, at: destinationURL)
                    } catch {
                        print("❌ Ошибка сохранения: \(error)")
                    }
                }
            }
        }

        let session = URLSession(configuration: .default, delegate: delegate, delegateQueue: OperationQueue())
        downloadTask = session.downloadTask(with: url)
        downloadTask?.resume()
    }

    // MARK: - Запуск приложения
    private func launchApp() {
        guard let path = installedManager.pathForApp(appId: app.id) else { return }
        NSWorkspace.shared.open(path)
    }
}
