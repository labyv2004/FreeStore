import SwiftUI

struct OnboardingView: View {
    var onFinish: () -> Void

    @State private var animateIcon = false
    @State private var animateCards = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color.accentColor.opacity(0.35),
                    Color.blue.opacity(0.2),
                    Color.purple.opacity(0.3)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            RoundedRectangle(cornerRadius: 32, style: .continuous)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 32, style: .continuous)
                        .strokeBorder(Color.white.opacity(0.1), lineWidth: 1)
                )
                .padding(32)
                .shadow(color: .black.opacity(0.35), radius: 24, x: 0, y: 18)

            VStack(spacing: 24) {
                VStack(spacing: 12) {
                    ZStack {
                        Circle()
                            .fill(Color.accentColor.opacity(0.18))
                            .frame(width: 120, height: 120)
                            .scaleEffect(animateIcon ? 1.05 : 0.95)
                            .animation(.easeInOut(duration: 1.6).repeatForever(autoreverses: true), value: animateIcon)

                        Image(systemName: "square.grid.2x2.fill")
                            .font(.system(size: 44, weight: .semibold))
                            .foregroundColor(.accentColor)
                            .rotationEffect(.degrees(animateIcon ? 6 : -4))
                            .animation(.easeInOut(duration: 1.8).repeatForever(autoreverses: true), value: animateIcon)
                    }

                    Text("Добро пожаловать в FreeStore")
                        .font(.system(size: 26, weight: .bold, design: .rounded))
                        .multilineTextAlignment(.center)

                    Text("Каталог приложений для macOS с избранным, поиском и быстрым запуском. Всё в одном аккуратном окне.")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: 420)
                }

                VStack(spacing: 16) {
                    featureRow(
                        icon: "star.fill",
                        title: "Избранное",
                        text: "Добавляйте любимые приложения в избранное и переключайтесь в отдельный раздел одним кликом.",
                        delay: 0.0
                    )

                    featureRow(
                        icon: "sparkles",
                        title: "Красивые анимации",
                        text: "Плавные переходы, подсветка выбора и аккуратная загрузка создают ощущение нативного App Store.",
                        delay: 0.08
                    )

                    featureRow(
                        icon: "magnifyingglass",
                        title: "Поиск и фильтры",
                        text: "Быстро находите нужное приложение по имени, описанию или статусу установки.",
                        delay: 0.16
                    )
                }
                .padding(.horizontal)

                Button(action: onFinish) {
                    HStack(spacing: 8) {
                        Text("Погнали")
                        Image(systemName: "arrow.right")
                    }
                    .font(.headline)
                    .padding(.horizontal, 26)
                    .padding(.vertical, 10)
                    .background(
                        Capsule(style: .continuous)
                            .fill(Color.accentColor)
                            .shadow(color: Color.accentColor.opacity(0.45), radius: 16, x: 0, y: 10)
                    )
                    .foregroundColor(.white)
                }
                .buttonStyle(.plain)
                .padding(.top, 4)
            }
            .padding(40)
        }
        .onAppear {
            animateIcon = true
            withAnimation(.spring(response: 0.7, dampingFraction: 0.8).delay(0.15)) {
                animateCards = true
            }
        }
    }

    @ViewBuilder
    private func featureRow(icon: String, title: String, text: String, delay: Double) -> some View {
        HStack(alignment: .top, spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color.accentColor.opacity(0.1))
                    .frame(width: 32, height: 32)
                Image(systemName: icon)
                    .foregroundColor(.accentColor)
                    .font(.system(size: 15, weight: .semibold))
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.subheadline.weight(.semibold))
                Text(text)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            Spacer()
        }
        .opacity(animateCards ? 1 : 0)
        .offset(y: animateCards ? 0 : 10)
        .animation(.spring(response: 0.7, dampingFraction: 0.85).delay(delay), value: animateCards)
    }
}

